class Updateable(object):
    def update_quality(self):
        raise NotImplementedError
